# Get-AdluminLogDeliveryStatus

**Proves that MikroTik syslog is still arriving in Adlumin**, by reading synthetic heartbeats back out
of the Adlumin API and alarming on their freshness.

Probe-run. Windows PowerShell 5.1. **Reads only — it holds no router credentials.**

---

## Why this exists

Every monitor in this estate is negative-signal: it reports when something bad happens and says
nothing when it can no longer report at all.

On **2026-08-19 the Adlumin collector stopped accepting events for 16.5 hours** and nothing raised it.
A person found it six hours in, opening the console for something else, and by then a scheduled
failover test had run and its results were unrecoverable — the only instrument was the collector.

**A liveness probe would not have caught it.** Throughout the outage the routers were transmitting,
the collector answered pings, and its service was running. The events simply never appeared. So this
service does not test reachability. **It tests delivery.**

### Why it does not run inside Adlumin

Adlumin can alert on its own feed going quiet, which is the obvious place for this. It is also the
wrong place: **the suspect system cannot be the thing that reports on the suspect system.** If the
collector dies, an Adlumin-side rule dies with it.

N-central breaks the circularity because its own liveness has three independent witnesses — engineers
are in it daily, N-Able alert on it, and Cloudflare health-checks it.

---

## How it works

**The device emits. This service only reads.**

1. A scheduler on each MikroTik logs `ADLUMINHEARTBEAT <identity>` every five minutes.
2. That reaches Adlumin through the normal syslog path — the same path everything else uses, which is
   the point.
3. This service queries the Adlumin API and grades **how old each device's newest heartbeat is**.

**No state is kept between runs.** The newest heartbeat in the SIEM is the state.

> ### An earlier version emitted the heartbeat itself, over the RouterOS REST API. That was wrong.
>
> It needed `read,write,test,rest-api` on every router — **a write-capable router credential sitting
> on a probe for the sake of a monitoring check.** In practice the only account with those rights was
> the `group=full` one N-central already writes configuration with.
>
> Emitting from a device-side scheduler needs **no router credential at all**, and it matches how
> everything else in this estate works: changes are applied to devices deliberately, not by a probe.

**If the scheduler stops firing, the heartbeat stops arriving and this alarms.** That is correct, not
a gap. The service does not try to distinguish *"the device stopped emitting"* from *"the collector
stopped delivering"* — both are worth waking up for.

---

## Device setup — one scheduler per device

```routeros
/system script add name=adlumin-heartbeat policy=read,test \
    source=":log warning (\"ADLUMINHEARTBEAT \" . [/system identity get name])"

/system scheduler add name=adlumin-heartbeat interval=5m on-event=adlumin-heartbeat \
    policy=read,test comment="N8 - synthetic heartbeat for the SIEM delivery check"
```

`:log warning` is deliberate. It matches the `warning` topic, which every device in this estate
already ships to Adlumin — **including RT-03, which ships only `critical`/`error`/`warning`/`vrrp`**.
An `info` heartbeat would be silently dropped there.

**Keep the scheduler interval well under `StaleMinutes`.** Five minutes against a 25-minute threshold
means five consecutive misses before the alarm, which rides out a reboot and normal ingestion lag.

### Which devices to deploy to

Verified live 2026-08-24:

| Device | Ships `warning` to Adlumin? | Deploy? |
| --- | --- | --- |
| `CCL-RT-01` `172.30.1.251` | yes | ✅ |
| `CCL-RT-02` `172.30.1.252` | yes | ✅ |
| `CCL-RT-03` `172.30.1.253` | yes — `warning` and `vrrp` only, which is why the heartbeat is a warning | ✅ |
| `CCL-S-Dude` `172.30.1.239` | yes — **since 2026-08-24** | ✅ |

> **The Dude was excluded until 2026-08-24 and is now in.** Its `/system logging` was memory-only with
> no `adlumin` action, so a heartbeat there would have been written locally, never left the box, and
> alarmed forever. **N3c** fixed that: the collector port question turned out to be stale (everything
> is on 20002, nothing on 20000), and the collector parses a CHR unaided.

---

## Inputs

| Variable | Notes |
| --- | --- |
| `AdluminTenantId` | |
| `AdluminApiKey` | **See the warning below** |
| `ExpectedHostnames` | Comma-separated device identities, e.g. `CCL-RT-01,CCL-RT-02,CCL-RT-03`. One name for a per-device service; several for a single service on the probe |
| `StaleMinutes` | Alarm when a device has been **silent** this long, after subtracting ingest lag. Default 25 |
| `LagWarnMinutes` | Report the collector as degraded above this ingest lag. Default 30 |
| `LookbackMinutes` | Search window. Default 180 |

`ExpectedHostnames` must match the device's `/system identity`, which is what appears in Adlumin's
`device_hostname`. A name that never appears is reported as **`NO HEARTBEAT`**, and a device sending
heartbeats nobody asked about is reported as a `Note:` — that pairing turns a hostname typo into an
obvious message rather than a mystery outage.

> ### ⚠️ The Adlumin API key is not read-only, and no read-only key type exists
>
> Confirmed with N-Able 2026-08-23. There is one key type and it can write — `POST
> /v1/acknowledge_detections` with `detection_id=all` acknowledges every unacknowledged detection in
> the tenant.
>
> This service issues **only GETs**, but that is a discipline rather than a control. Storing the key
> on a probe is a deliberate, accepted risk: the blast radius is a detection status flag, not a secret
> and not a configuration change. Revisit if Adlumin ever ships scoped keys.

---

## Outputs

| # | Output | Type | Sentinel | Meaning |
| --- | --- | --- | --- | --- |
| 1 | `StaleDeviceCount` | int | `-1` | Devices that have genuinely **stopped emitting** — freshness minus ingest lag. **Returns to `-1` when the collector is too far behind to assess silence**, because "0 stale" would read as "all well" when the truth is "not determined" |
| 2 | `MaxFreshnessMinutes` | int | `-1` | Worst heartbeat age across the expected devices |
| 3 | `MaxCopyCount` | int | `-1` | Worst duplication seen. **1 is correct** |
| 4 | `Info` | string | `Error: scan did not complete` | Per-device detail, `Error:` prefixed |

`-1` means "not collected this scan" and is promoted to `0` only once the API has actually answered.
**A failed scan reporting `0` stale devices is indistinguishable from a healthy one** — which is the
exact negative-signal failure this service exists to stop.

### Thresholds

| Output | Threshold |
| --- | --- |
| `StaleDeviceCount` | **Failed if `> 0`** |
| `Info` | **Failed if String contains `Error:`** — **not the house `N/A` pattern.** This service follows WRITING-CUSTOM-SERVICES §3, where errors are collected and prefixed to `Info` as `Error:`. Configuring it as `N/A` instead silently disarms every error this service can raise, which happened on the first deployment: a "collector is 87 minutes behind" line displayed and thresholded nothing |
| `MaxCopyCount` | Warning if `> 1` |
| `MaxFreshnessMinutes` | Off — for reading and trending |

**Service interval: 15 or 30 minutes.** Five will alarm on normal ingestion lag, which has been
measured at ~4 minutes and occasionally 20.

---

## What `MaxCopyCount` is really for

Between **2026-08-20 and 21:30 on 2026-08-23**, this collector delivered every event **five to six
times**, at roughly 30-second intervals, across two unrelated vendors simultaneously. It then stopped
on its own, with no change at either sender. The cause is still open with N-Able.

**While that is happening, every count taken from the SIEM is inflated by an unknown, varying
factor** — one investigation published a wrong conclusion off the back of it.

`MaxCopyCount` makes it visible from a single probe instead of a bulk export, and it will show the
fault returning the day it returns.

---

## Traps this service is written around

Each produced a wrong answer on this platform before the service existed.

- **`start` and `end` are UTC**, and nothing in the API documentation says so. A local-time window
  silently returns the wrong half-day in New Zealand — or nothing, which reads as a dead pipeline.
- **`query` is a loose token match, and punctuation binds into the token.** Searching `CATCHALL`
  returns *nothing* in a window full of `CATCHALL_` messages. **This is why the marker is
  `ADLUMINHEARTBEAT` and not `ADLUMIN-HEARTBEAT`** — a hyphen would make the heartbeat unfindable by
  the very query the check depends on.
- **`query` is also over-inclusive**: `CCL-RT-01` returns 89% of the corpus because `CCL` is a token.
  Results are filtered client-side on the marker and on `device_hostname`.
- **`dvchost` is always `null`**; `device_hostname` is the populated field.
- **Three timestamps per record disagree.** `timewritten` is naive UTC on syslog records and
  local-with-offset on others; `Event Time` has presented events **77 seconds out of order**. Only the
  device's own syslog header timestamp is trustworthy, so that is what the freshness maths uses.
- **`record_id` is unique per delivered copy**, so it cannot deduplicate. Copies are grouped by device
  timestamp instead.
- **Results are paged.** When the collector is duplicating, a handful of heartbeats becomes several
  hundred rows and a single 500-row page truncates — which would make a live device look stale. The
  service scrolls, and says so in a `Note:` if it ever hits the paging cap rather than truncating
  quietly.
- **"No records found" arrives with HTTP 200** in a `failed` property, not as an error.
- **An undocumented rate limit exists** (HTTP 429 under light use), hence the pacing between pages.

---

## Testing

Environment variables, read from **User scope first, then Machine** — in practice they end up split
across both, and a missing one presents as an empty credential rather than an error:

```powershell
$env:ADLUMIN_TENANT_ID
$env:ADLUMIN_API_KEY
```

The test block warns explicitly when a required value is empty.

Run the script directly. It only populates the test block when `UserInteractive` is true **and**
`$ExpectedHostnames` is empty, so it can never override what N-central supplies.

**Before the schedulers are deployed, the correct output is a full set of failures:**

```
3
0
0
Error: CCL-RT-01 has no heartbeat in Adlumin at all - searched the last 180 minutes
Error: CCL-RT-02 has no heartbeat in Adlumin at all - searched the last 180 minutes
Error: CCL-RT-03 has no heartbeat in Adlumin at all - searched the last 180 minutes

CCL-RT-01 | NO HEARTBEAT in 180 min
CCL-RT-02 | NO HEARTBEAT in 180 min
CCL-RT-03 | NO HEARTBEAT in 180 min
```

Healthy, once they are:

```
0
4
1
CCL-RT-01 | ok, 2 min old | 1 copies | ingest lag 47s
CCL-RT-02 | ok, 4 min old | 1 copies | ingest lag 52s
CCL-RT-03 | ok, 3 min old | 1 copies | ingest lag 61s
```

---

## Freshness is not silence, and on 2026-08-25 that was the whole answer

The first live run in N-central reported **`CCL-RT-01 has not delivered a heartbeat for 45 minutes`**
and flagged two devices stale. **Both were emitting perfectly, every five minutes.**

What had changed was the collector:

| | 2026-08-24 16:20–17:10 | 2026-08-25 07:00–09:00 |
| --- | --- | --- |
| median ingest lag | **224 s** | **2 655 s** |
| p90 | 264 s | 5 019 s |
| max | 284 s | **5 770 s** |

**A heartbeat cannot appear in the SIEM sooner than the collector is running behind.** With median lag
at 44 minutes, freshness reads 30–50 minutes on a device that emitted two minutes ago, and any
`StaleMinutes` under the lag alarms on everything.

So the service now subtracts lag from freshness and alarms on what is left — **how long the device has
actually been quiet.** Excessive lag is reported separately, as a degraded collector, and worded so
nobody goes looking at a router that is behaving.

**The distinction earned itself immediately.** Re-run against the same data, three of the four
alarms vanished and one survived: RT-01's heartbeats stopped at 08:08:29 while its *other* events kept
arriving to 08:50:17 — its scheduler had stopped, and nothing else had. **One real fault, three false
positives removed.**

> **A caveat worth keeping.** Lag is taken from one settled event, and lag is currently varying between
> 336 s and 5 770 s. Subtracting a noisy estimate makes the silence figure noisy too. It is right in
> principle and approximate in practice — treat a single `SILENT` reading as a prompt to look, not as
> proof, and confirm on the device.
