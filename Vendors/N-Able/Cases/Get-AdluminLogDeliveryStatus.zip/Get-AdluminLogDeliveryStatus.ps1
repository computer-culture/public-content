<#

    .SYNOPSIS
    Proves that MikroTik devices' syslog is still arriving in Adlumin, by reading synthetic
    heartbeats back out of the Adlumin API and alarming on their freshness.

    Designed to be run from within an N-central custom service, on a probe.

    .DESCRIPTION
    This is a POSITIVE-SIGNAL check. Every other monitor in this estate reports when something bad
    happens and says nothing when it can no longer report at all. On 2026-08-19 the Adlumin collector
    stopped accepting events for 16.5 hours and nothing raised it; it was found by a person opening
    the console for an unrelated reason, by which time a failover test's results had been lost.

    A liveness probe would NOT have caught that. Throughout the outage the routers were transmitting,
    the collector answered pings and its service was running - the events simply never appeared. So
    this service deliberately does not test reachability. It tests DELIVERY: something known was sent,
    and the question is whether it can be read back out of the SIEM.

    THE DEVICE EMITS, THIS SERVICE ONLY READS.

    An earlier version made the heartbeat itself over the RouterOS REST API. That needed
    read,write,test,rest-api on every router, which is a write-capable router credential sitting on a
    probe for the sake of a monitoring check - and in practice the only account with those rights was
    the group=full one N-central already writes configuration with.

    Emitting from a device-side scheduler instead means this service needs NO router credential at
    all, only the Adlumin API key. It is also the estate's normal way of working: changes are applied
    to devices deliberately, not by a monitoring probe.

    The scheduler is one line and lives in the .md.

    If the device scheduler stops firing, the heartbeat stops arriving and this alarms. That is the
    correct outcome, not a gap - the service does not attempt to distinguish "the device stopped
    emitting" from "the collector stopped delivering", because both are worth waking up for.

    .INPUTS
    Passed in from N-central:
    $AdluminTenantId   - Adlumin tenant ID
    $AdluminApiKey     - Adlumin API key. NOTE: no read-only key type exists - see the .md
    $ExpectedHostnames - Comma-separated device identities to expect, e.g. "CCL-RT-01,CCL-RT-02"
                         One name for a per-device service; several for one service on the probe.
    $StaleMinutes      - Alarm if a device's newest heartbeat is older than this. Default 25.
    $LookbackMinutes   - How far back to search. Default 180.

#>

# ---------------------------------------------------------------------------------------------
# Input variables
# ---------------------------------------------------------------------------------------------

# Test-block secrets live in environment variables, never in this file. Read User scope first and
# Machine second, because in practice they end up split across both - and a missing one fails as an
# empty credential rather than as an error, which presents as "the API is down".
function Get-TestSecret($Name)
{
    $Value = [System.Environment]::GetEnvironmentVariable($Name, "User")
    if (-not $Value) { $Value = [System.Environment]::GetEnvironmentVariable($Name, "Machine") }
    return $Value
}

# The -not $ExpectedHostnames clause matters. Without it, any context where UserInteractive is true
# would override what N-central supplies and point every customer's service at the names below.
if ([Environment]::UserInteractive -eq $true -and -not $ExpectedHostnames)
{
    $ExpectedHostnames = "CCL-RT-01,CCL-RT-02,CCL-RT-03,CCL-S-Dude"
    $AdluminTenantId   = Get-TestSecret "ADLUMIN_TENANT_ID"
    $AdluminApiKey     = Get-TestSecret "ADLUMIN_API_KEY"
    $StaleMinutes      = 25
    $LookbackMinutes   = 180

    foreach ($Required in @("AdluminTenantId","AdluminApiKey"))
    {
        if (-not (Get-Variable -Name $Required -ValueOnly -ErrorAction SilentlyContinue))
        {
            Write-Host "TEST BLOCK: `$$Required is empty - check the environment variable exists in User or Machine scope" -ForegroundColor Yellow
        }
    }
}

if (-not $StaleMinutes)    { $StaleMinutes = 25 }
if (-not $LookbackMinutes) { $LookbackMinutes = 180 }

# Copies of a single event arrive over roughly two to three minutes, so the newest heartbeat has
# almost never finished arriving. Copies and lag are graded on the newest event older than this.
if (-not $SettleMinutes)   { $SettleMinutes = 6 }

# Ingest lag above this is reported as a degraded collector rather than a silent device. 30 minutes is
# generous: normal was ~4 minutes until 2026-08-25, when the median went to 44.
if (-not $LagWarnMinutes) { $LagWarnMinutes = 30 }

# ---------------------------------------------------------------------------------------------
# Outputs, initialised to typed "not collected" sentinels
#
# -1 rather than 0 on every counter. A failed scan reporting 0 stale devices is indistinguishable
# from a healthy one, and a threshold of "Failed if > 0" would go green on a scan that never ran -
# which is the exact negative-signal failure this service exists to stop.
# ---------------------------------------------------------------------------------------------

$StaleDeviceCount    = -1
$MaxFreshnessMinutes = -1
$MaxCopyCount        = -1
$Info                = "Error: scan did not complete"

$ScanErrors = @()
$ScanNotes  = @()
$InfoLines  = @()

# The heartbeat marker is deliberately a SINGLE ALPHANUMERIC TOKEN with no hyphen or underscore.
# Adlumin's query parameter is a token match and punctuation binds into the token: searching
# "CATCHALL" returns nothing in a window full of "CATCHALL_" messages. A marker containing a hyphen
# would be unfindable by the very query this service depends on.
$HeartbeatMarker = "ADLUMINHEARTBEAT"

function Add-ScanError($Reason, $Context)
{
    $script:ScanErrors += "$Reason - $Context"
}

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

# ---------------------------------------------------------------------------------------------

try
{
    $NzNow = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date).ToUniversalTime(), "New Zealand Standard Time")

    $Expected = @()
    if ($ExpectedHostnames)
    {
        $Expected = @($ExpectedHostnames -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
    }

    if ($Expected.Count -eq 0)
    {
        Add-ScanError -Reason "No expected hostnames supplied" -Context "check the service configuration"
    }
    elseif (-not $AdluminApiKey -or -not $AdluminTenantId)
    {
        Add-ScanError -Reason "Adlumin API key or tenant ID not supplied" -Context "check the service configuration"
    }
    else
    {
        # -----------------------------------------------------------------------------------------
        # Fetch every heartbeat in the window
        #
        # start and end are UTC and nothing in the API documentation says so. A local-time window
        # silently returns the wrong half-day in New Zealand, or nothing at all, which would read as
        # a dead pipeline. Convert explicitly.
        #
        # Paged, because when the collector is duplicating - which it did for at least three days -
        # a handful of heartbeats becomes several hundred rows and a single 500-row page truncates.
        # -----------------------------------------------------------------------------------------

        $UtcNow   = (Get-Date).ToUniversalTime()
        $UtcStart = $UtcNow.AddMinutes(-1 * [int]$LookbackMinutes)
        $Fmt      = "yyyy-MM-dd-HH:mm:ss"

        $BaseUri = "https://api.adlumin.com/v1/network_data" +
                   "?tenant_id=" + [System.Uri]::EscapeDataString($AdluminTenantId)

        $FirstUri = $BaseUri +
                    "&start=" + $UtcStart.ToString($Fmt, [System.Globalization.CultureInfo]::InvariantCulture) +
                    "&end="   + $UtcNow.ToString($Fmt,   [System.Globalization.CultureInfo]::InvariantCulture) +
                    "&query=" + [System.Uri]::EscapeDataString($HeartbeatMarker)

        $Records  = @()
        $ScrollId = $null
        $Page     = 0
        $Total    = 0
        $Fetched  = $true

        while ($Fetched -and $Page -lt 8)
        {
            if ($ScrollId) { $Uri = $BaseUri + "&scroll_id=" + [System.Uri]::EscapeDataString($ScrollId) }
            else           { $Uri = $FirstUri }

            $Response = $null

            # Retry once. A probe reaching an internet API will eventually see a transient, and
            # alerting on a first failure produces a service nobody trusts.
            for ($Attempt = 1; $Attempt -le 2; $Attempt++)
            {
                try
                {
                    $Response = Invoke-RestMethod -Uri $Uri -Headers @{ "x-api-key" = $AdluminApiKey } -Method Get -TimeoutSec 60
                    break
                }
                catch
                {
                    if ($Attempt -eq 2) { Add-ScanError -Reason "Adlumin API query failed" -Context $_.Exception.Message }
                    else { $ScanNotes += "Adlumin API retried once"; Start-Sleep -Seconds 5 }
                }
            }

            if (-not $Response -or -not $Response.records)
            {
                # "No records found" arrives in a failed property with HTTP 200, not as an error.
                $Fetched = $false
            }
            else
            {
                if ($Page -eq 0 -and $Response.total_records) { $Total = [int]$Response.total_records }
                $Records += @($Response.records)
                $ScrollId = $Response.scroll_id
                $Page++
                if (-not $ScrollId -or $Records.Count -ge $Total) { $Fetched = $false }
                else { Start-Sleep -Milliseconds 400 }
            }
        }

        if ($Total -gt 0 -and $Records.Count -lt $Total)
        {
            # Never truncate silently. A partial fetch could make a live device look stale.
            $ScanNotes += "Fetched $($Records.Count) of $Total rows - paging cap reached"
        }

        # -----------------------------------------------------------------------------------------
        # Reduce to the newest heartbeat per device
        #
        # The query parameter is a loose token match and over-inclusive - searching CCL-RT-01 returns
        # 89% of the corpus because CCL is a token - so filter client-side on the marker actually
        # appearing in the raw message. dvchost is always null on parsed records; device_hostname is
        # the populated field.
        # -----------------------------------------------------------------------------------------

        # Two questions need two different events, and conflating them undercounts duplication
        # badly. Copies of one event arrive over roughly two to three minutes, so the NEWEST
        # heartbeat has almost never finished arriving. Grading copies on it reported "1 copy" on
        # 2026-08-24 while the collector was in fact duplicating sixfold - a false negative on the
        # one indicator that shows the fault coming back.
        #
        # Freshness comes from the newest event; copies and lag from the newest SETTLED one.
        $Events = @{}   # hostKey -> @{ Name; Stamps = @{ stamp -> @{ Time; Copies; Processed } } }

        foreach ($Record in $Records)
        {
            if (-not $Record.message_raw) { continue }
            if ($Record.message_raw -notmatch $HeartbeatMarker) { continue }
            if ($Record.message_raw -notmatch '^(\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2})\s+(\S+)\s') { continue }

            $Stamp = $matches[1]
            $HostName  = [string]$Record.device_hostname
            if (-not $HostName) { $HostName = $matches[2] }

            # BSD syslog carries no year. Assume the current one, and step back a year if that puts
            # the event in the future - which only happens across a 31 December rollover.
            $Parsed = $null
            foreach ($Pattern in @("MMM d HH:mm:ss yyyy","MMM dd HH:mm:ss yyyy"))
            {
                try { $Parsed = [datetime]::ParseExact("$Stamp $($NzNow.Year)", $Pattern, [System.Globalization.CultureInfo]::InvariantCulture); break } catch { }
            }
            if (-not $Parsed) { continue }
            if ($Parsed -gt $NzNow.AddDays(1)) { $Parsed = $Parsed.AddYears(-1) }

            $Key = $HostName.ToUpper()
            if (-not $Events.ContainsKey($Key)) { $Events[$Key] = @{ Name = $HostName; Stamps = @{} } }
            if (-not $Events[$Key].Stamps.ContainsKey($Stamp))
            {
                $Events[$Key].Stamps[$Stamp] = @{ Time = $Parsed; Copies = 0; Processed = $null; Name = $HostName }
            }

            $Events[$Key].Stamps[$Stamp].Copies++

            # Earliest processed timestamp of the copies. With duplicates the later ones are
            # retries, and averaging them would overstate the real delivery time.
            if ($Record.adlumin_date_time_processed)
            {
                try
                {
                    $P = [datetime]$Record.adlumin_date_time_processed
                    if (-not $Events[$Key].Stamps[$Stamp].Processed -or $P -lt $Events[$Key].Stamps[$Stamp].Processed)
                    {
                        $Events[$Key].Stamps[$Stamp].Processed = $P
                    }
                }
                catch { }
            }
        }

        # Collapse to one newest and one newest-settled per device.
        $Newest  = @{}
        $Settled = @{}

        foreach ($Key in $Events.Keys)
        {
            foreach ($Stamp in $Events[$Key].Stamps.Keys)
            {
                $Entry = $Events[$Key].Stamps[$Stamp]

                if (-not $Newest.ContainsKey($Key) -or $Entry.Time -gt $Newest[$Key].Time) { $Newest[$Key] = $Entry }

                if (($NzNow - $Entry.Time).TotalMinutes -ge [double]$SettleMinutes)
                {
                    if (-not $Settled.ContainsKey($Key) -or $Entry.Time -gt $Settled[$Key].Time) { $Settled[$Key] = $Entry }
                }
            }
        }

        # -----------------------------------------------------------------------------------------
        # Grade each expected device
        # -----------------------------------------------------------------------------------------

        # We have data now, so 0 is a real answer rather than "not collected".
        $StaleDeviceCount    = 0
        $MaxFreshnessMinutes = 0
        $MaxCopyCount        = 0

        # The lag floor, and it is the difference between a useful alarm and a nuisance one.
        #
        # Subtracting a device's OWN lag is not enough, because lag varies enormously between devices
        # at the same instant: on 2026-08-25 12:30 RT-01 measured 304 s while RT-02 measured 1 706 s.
        # A device whose settled sample happens to be a fast one gets too small a subtraction, and its
        # not-yet-ingested heartbeats read as silence. That produced a confident, wrong "CCL-RT-01 has
        # stopped emitting" about a router whose scheduler had run 241 times without missing one.
        #
        # So take the WORST lag seen across all devices this scan. If the collector demonstrably took
        # 28 minutes to deliver somebody's heartbeat, nothing can be called silent until it has been
        # quiet for longer than that. It is deliberately conservative: when the collector is badly
        # behind, a genuinely dead device takes longer to spot - and that is the honest position,
        # because the evidence to tell them apart does not exist yet.
        # Built from EVERY event in the window, not the four newest settled ones. Four samples cannot
        # see the tail of a distribution that ran from 336 s to 5 770 s in a single morning, and a
        # floor built from four fast samples still accuses whichever device happened to be slow.
        # p90 rather than max, so one stuck record does not disable the check entirely.
        $AllLags = @()
        foreach ($K in $Events.Keys)
        {
            foreach ($St in $Events[$K].Stamps.Keys)
            {
                $E = $Events[$K].Stamps[$St]
                if ($E.Processed)
                {
                    $L = ($E.Processed - $E.Time).TotalSeconds
                    if ($L -gt 0) { $AllLags += $L }
                }
            }
        }

        $LagFloorMinutes = 0
        if ($AllLags.Count -gt 0)
        {
            $Sorted = @($AllLags | Sort-Object)
            $Idx = [int]([Math]::Floor($Sorted.Count * 0.9))
            if ($Idx -ge $Sorted.Count) { $Idx = $Sorted.Count - 1 }
            $LagFloorMinutes = [int][Math]::Round($Sorted[$Idx] / 60)
        }

        # When the collector is further behind than the silence threshold, the question this service
        # asks cannot be answered. A device that stopped 30 minutes ago and a device whose last three
        # heartbeats are still queued look identical, and no amount of arithmetic separates them.
        #
        # Say so, loudly, instead of guessing. The Error puts the service into Failed on the Info
        # threshold, so the pipeline problem still raises an alarm - it just raises the correct one,
        # rather than naming a router that is behaving perfectly. Silence grading is suspended for
        # the scan.
        $CanAssessSilence = ($LagFloorMinutes -le [int]$StaleMinutes)

        if (-not $CanAssessSilence)
        {
            Add-ScanError -Reason "Collector is running $LagFloorMinutes minutes behind (p90)" -Context "device silence cannot be assessed this scan; heartbeats are still arriving"

            # Back to the "not collected" sentinel, deliberately. Reporting 0 here would be a lie of
            # exactly the kind this service exists to stop: it reads as "no device is stale" when the
            # truth is "whether any device is stale was not determined". -1 is the honest answer and
            # it keeps the scalar output alarming even if the Info threshold is misconfigured, which
            # is a mistake worth being robust against - it happened on the first deployment.
            $StaleDeviceCount = -1
        }

        foreach ($Name in $Expected)
        {
            $Key = $Name.ToUpper()

            if (-not $Newest.ContainsKey($Key))
            {
                $StaleDeviceCount++
                # Deliberately worded to separate "never arrived" from "has gone stale". On a first
                # deployment the former is expected and the latter is not.
                Add-ScanError -Reason "$Name has no heartbeat in Adlumin at all" -Context "searched the last $LookbackMinutes minutes"
                $InfoLines += "$Name | NO HEARTBEAT in $LookbackMinutes min"
                continue
            }

            # Freshness: the newest heartbeat, however recently it landed.
            $Entry = $Newest[$Key]
            $AgeMinutes = [int][Math]::Round(($NzNow - $Entry.Time).TotalMinutes)
            if ($AgeMinutes -lt 0) { $AgeMinutes = 0 }
            if ($AgeMinutes -gt $MaxFreshnessMinutes) { $MaxFreshnessMinutes = $AgeMinutes }

            # Copies and lag: the newest heartbeat whose copies have had time to arrive. Reporting
            # these off the newest event undercounts duplication to the point of hiding it.
            $CopyText   = "copies pending"
            $LagText    = "lag pending"
            $LagMinutes = -1

            if ($Settled.ContainsKey($Key))
            {
                $Ref = $Settled[$Key]
                if ($Ref.Copies -gt $MaxCopyCount) { $MaxCopyCount = $Ref.Copies }
                $CopyText = "$($Ref.Copies) copies"

                if ($Ref.Processed)
                {
                    $Lag = [int][Math]::Round(($Ref.Processed - $Ref.Time).TotalSeconds)
                    if ($Lag -lt 0) { $Lag = 0 }
                    $LagText    = "ingest lag ${Lag}s"
                    $LagMinutes = [int][Math]::Round($Lag / 60)
                }
            }

            # Freshness alone cannot tell a silent device from a slow collector, and on 2026-08-25
            # that distinction was the whole answer: every device was emitting on schedule while
            # median ingestion lag had gone from 224 s to 2 655 s, so freshness read 27-45 minutes on
            # devices that were perfectly healthy. Alarming on freshness alone made the service
            # report "CCL-RT-01 has not delivered a heartbeat" about a router that had.
            #
            # A heartbeat cannot appear in the SIEM sooner than the collector is running behind, so
            # subtract the lag. What is left is how long the DEVICE has actually been quiet.
            # Use the worst lag seen anywhere this scan, not this device's own sample - see the note
            # where $LagFloorMinutes is built.
            $Allowance = $LagFloorMinutes
            if ($LagMinutes -gt $Allowance) { $Allowance = $LagMinutes }

            $SilenceMinutes = $AgeMinutes - $Allowance
            if ($SilenceMinutes -lt 0) { $SilenceMinutes = 0 }

            if (-not $CanAssessSilence)
            {
                $InfoLines += "$Name | seen $AgeMinutes min ago | silence not assessable | $CopyText | $LagText"
            }
            elseif ($SilenceMinutes -gt [int]$StaleMinutes)
            {
                $StaleDeviceCount++
                Add-ScanError -Reason "$Name has stopped emitting - silent for $SilenceMinutes minutes after allowing for ingest lag" -Context "threshold is $StaleMinutes"
                $InfoLines += "$Name | SILENT $SilenceMinutes min | seen $AgeMinutes min ago | $CopyText | $LagText"
            }
            elseif ($LagMinutes -ge 0 -and $LagMinutes -gt [int]$LagWarnMinutes)
            {
                # The device is fine and the pipeline is degraded. Worth an Error - anything built on
                # this feed is now that far behind reality - but worded so nobody goes looking at a
                # router that is behaving.
                Add-ScanError -Reason "Collector is $LagMinutes minutes behind on $Name" -Context "device is emitting normally; ingest lag threshold is $LagWarnMinutes"
                $InfoLines += "$Name | ok, emitting | LAGGED $LagMinutes min | $CopyText"
            }
            else
            {
                $InfoLines += "$Name | ok, $AgeMinutes min old | $CopyText | $LagText"
            }
        }

        if ($MaxCopyCount -gt 1)
        {
            # Not a delivery failure, so a Note rather than an Error - but it is the amplification
            # fault this estate spent a week measuring, and while it persists every count taken from
            # this feed is wrong by an unknown, varying factor.
            $ScanNotes += "Duplication is active - worst event delivered $MaxCopyCount times"
        }

        # Devices sending heartbeats that nobody asked about. Usually a hostname typo in the service
        # configuration, which would otherwise present as a device that has never reported.
        foreach ($Key in $Newest.Keys)
        {
            $Known = $false
            foreach ($Name in $Expected) { if ($Name.ToUpper() -eq $Key) { $Known = $true } }
            if (-not $Known) { $ScanNotes += "Unexpected device sending heartbeats: $($Newest[$Key].Name)" }
        }
    }
}
catch
{
    Add-ScanError -Reason "Unhandled scan error" -Context $_.Exception.Message
}
finally
{
    $NzScanTime = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date).ToUniversalTime(), "New Zealand Standard Time")

    $Assembled = @()
    foreach ($ScanError in ($ScanErrors | Select-Object -Unique)) { $Assembled += "Error: $ScanError" }
    foreach ($ScanNote  in ($ScanNotes  | Select-Object -Unique)) { $Assembled += "Note: $ScanNote" }
    if ($Assembled.Count -gt 0 -and $InfoLines.Count -gt 0) { $Assembled += "" }
    $Assembled += $InfoLines
    $Assembled += ""
    $Assembled += "Scanned $($NzScanTime.ToString('dd/MM/yyyy HH:mm', [System.Globalization.CultureInfo]::InvariantCulture)) NZT"

    # <br> is the only line break that renders in the N-central GUI, and the leading one stops the
    # first line running into the property label.
    $Info = "<br>" + ($Assembled -join "<br>")

    # Every output on every path, cast on the way out. A missing output shifts every following value
    # into the wrong N-central field with no error anywhere.
    Write-Output ([int]$StaleDeviceCount)
    Write-Output ([int]$MaxFreshnessMinutes)
    Write-Output ([int]$MaxCopyCount)
    Write-Output ([string]$Info)

    Write-Host ($Info -replace "<br>", "`r`n")
}
